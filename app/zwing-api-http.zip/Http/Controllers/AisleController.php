<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Aisle;

class AisleController extends Controller
{
    public function aisle_products(Request $request){



    }

}
