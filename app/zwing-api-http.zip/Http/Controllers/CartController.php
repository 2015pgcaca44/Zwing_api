<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\Cart;
use App\Address;
use App\PartnerOffer;
use App\PartnerOfferUsed;
use DB;
use App\Payment;
use Endroid\QrCode\QrCode;
use App\Wishlist;
use Auth;
use Razorpay\Api\Api;

class CartController extends Controller
{
    
    public function __construct()
	{
		$this->middleware('auth',   ['except' => ['order_receipt']]);
	}

	public function add_to_cart(Request $request)
    {

        $v_id = $request->v_id;

        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->add_to_cart($request);
            return $response;

        } else if($v_id == 3) {

            $cartC = new  Vmart\CartController;
            $response = $cartC->add_to_cart($request);
            return $response;

        }else if($v_id == 26) {

            $cartC = new  Zwing\CartController;
            $response = $cartC->add_to_cart($request);
            return $response;

        }else if($v_id == 28) {

            $cartC = new  Dmart\CartController;
            $response = $cartC->add_to_cart($request);
            return $response;

        }else if($v_id == 30) {

            $cartC = new  Hero\CartController;
            $response = $cartC->add_to_cart($request);
            return $response;

        }  else { 

            $v_id = $request->v_id;
            $c_id = $request->c_id;
            $store_id = $request->store_id;
            $product_id = $request->product_id;
            $barcode = $request->barcode;
            $qty = $request->qty;
            $amount = $request->amount;

            $order_id = Order::where('user_id', $c_id)->where('status', 'success')->count();
            $order_id = $order_id + 1;

            $check_product_exists = Cart::where('store_id', $store_id)->where('v_id', $v_id)->where('order_id', $order_id)->where('user_id', $c_id)->where('product_id', $product_id)->where('barcode', $barcode)->where('status', 'process')->count();

            if(!empty($check_product_exists)) {
            	return response()->json(['status' => 'product_already_exists', 'message' => 'Product Already Exists' ], 409);
            }

            $cart = new Cart;

            $cart->store_id = $store_id;
            $cart->v_id = $v_id;
            $cart->order_id = $order_id;
            $cart->user_id = $c_id;
            $cart->product_id = $product_id;
            $cart->barcode = $barcode;
            $cart->qty = $qty;
            $cart->amount = $amount;
            $cart->status = 'process';
            $cart->date = date('Y-m-d');
            $cart->time = date('h:i:s');
            $cart->month = date('m');
            $cart->year = date('Y');

            $cart->save();

            return response()->json(['status' => 'add_to_cart', 'message' => 'Product was successfully added to your cart.', 'data' => $cart ],200);
        }
    }

    public function product_qty_update(Request $request)
    {
    	$v_id = $request->v_id;

        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->product_qty_update($request);
            return $response;

        } else if($v_id == 3) {

            $cartC = new  Vmart\CartController;
            $response = $cartC->product_qty_update($request);
            return $response;

        }else if($v_id == 26) {

            $cartC = new  Zwing\CartController;
            $response = $cartC->product_qty_update($request);
            return $response;

        }else if($v_id == 28) {

            $cartC = new  Dmart\CartController;
            $response = $cartC->product_qty_update($request);
            return $response;

        }else if($v_id == 30) {

            $cartC = new  Hero\CartController;
            $response = $cartC->product_qty_update($request);
            return $response;

        } else {

            $c_id = $request->c_id;
            $store_id = $request->store_id;
            $product_id = $request->product_id;
            $barcode = $request->barcode;
            $qty = $request->qty;
            $amount = $request->amount;

            $order_id = Order::where('user_id', $c_id)->where('status', 'success')->count();
            $order_id = $order_id + 1;

            $check_product_exists = Cart::where('store_id', $store_id)->where('v_id', $v_id)->where('order_id', $order_id)->where('user_id', $c_id)->where('product_id', $product_id)->where('barcode', $barcode)->where('status', 'process')->first();

            $check_product_exists->qty = $check_product_exists->qty + $qty;
            $check_product_exists->amount = $check_product_exists->amount + $amount;

            $check_product_exists->save();

            return response()->json(['status' => 'product_qty_update', 'message' => 'Product quantity successfully Updated'], 200);


        }
        
    }

    public function remove_product(Request $request)
    {

        $v_id = $request->v_id;

        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->remove_product($request);
            return $response;

        } else if($v_id == 3){
           
            $cartC = new  Vmart\CartController;
            $response = $cartC->remove_product($request);
            return $response;

        } else if($v_id == 26){
           
            $cartC = new  Zwing\CartController;
            $response = $cartC->remove_product($request);
            return $response;

        } else if($v_id == 28){
           
            $cartC = new  Dmart\CartController;
            $response = $cartC->remove_product($request);
            return $response;

        } else if($v_id == 30){
           
            $cartC = new  Hero\CartController;
            $response = $cartC->remove_product($request);
            return $response;

        } else {
        	$c_id = $request->c_id;
        	$store_id = $request->store_id;
        	$v_id = $request->v_id;
        	$cart_id = $request->cart_id;
        	$product_id = $request->product_id;

        	Cart::where('cart_id', $cart_id)->where('store_id', $store_id)->where('v_id', $v_id)->where('user_id', $c_id)->where('product_id', $product_id)->delete();

        	return response()->json(['status' => 'remove_product', 'message' => 'Remove Product' ],200);
        }
    }

    public function cart_details(Request $request)
    {


        $v_id = $request->v_id;

        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->cart_details($request);
            return $response;

        } elseif($v_id == 3) {

            $cartC = new  Vmart\CartController;
            $response = $cartC->cart_details($request);
            return $response;

        } elseif($v_id == 26) {

            $cartC = new  Zwing\CartController;
            $response = $cartC->cart_details($request);
            return $response;

        }elseif($v_id == 28) {

            $cartC = new  Dmart\CartController;
            $response = $cartC->cart_details($request);
            return $response;

        }elseif($v_id == 30) {

            $cartC = new  Hero\CartController;
            $response = $cartC->cart_details($request);
            return $response;

        }   else {

            $v_id = $request->v_id;
            $c_id = $request->c_id;
            $store_id = $request->store_id; 

            $cart_data = array();
            $product_data = [];
            $tax_total = 0;
    		$cart_qty_total = 0;
            //$order_id = Order::where('user_id', $c_id)->where('status', 'success')->orWhere('status' ,'error')->count();
    		$order_id = Order::where('user_id', $c_id)->where('status', 'success')->count();
            $order_id = $order_id + 1;
            
            $carts = Cart::where('user_id', $c_id)->where('v_id', $v_id)->where('store_id', $store_id)->where('status','process')->get();
            $sub_total = Cart::where('user_id', $c_id)->where('v_id', $v_id)->where('store_id', $store_id)->where('status','process')->sum('amount');
            $price = array();
            $rprice = array();
            $qty = array();
            $merge = array();
            $saving = 0;
            foreach ($carts as $key => $cart) {
                 //$product = DB::table('zwv_inventory'.$v_id.$store_id)->where('barcode', $value->barcode)->first();
                $api_link_column = DB::table('api_link')->select('API_Column','V_API_Column')->where('Table', 'zwv_inventory'.$v_id.$store_id)->where('cart_view', 1)->get();
                foreach ($api_link_column as $key => $value) {
                    $api_column_id = $value->API_Column;
                    $api_columns = DB::table('api_columns')->select('api_id','Name')->where('api_id', $api_column_id)->first();
                    $v_column = get_vendor_column_name($value->V_API_Column,$v_id,$store_id);
                    $product_details = DB::table('zwv_inventory'.$v_id.$store_id)->select($v_column,'tax_hsn_id','s_price as mrp')->where('barcode', $cart->barcode)->first();
                    $tax = DB::table('zwing_tax'.$v_id)->where('vtax_id', $product_details->tax_hsn_id)->first();
                    $tax_amount = $product_details->mrp * $cart->qty * $tax->igst_rate / 100;
                    $product_data[get_api_column_name($value->API_Column)] = $product_details->$v_column;
                    $whishlist = Wishlist::where('v_id', $v_id)->where('store_id', $store_id)->where('barcode', $cart->barcode)->where('user_id', $c_id)->count();
                    if(get_api_column_name($value->API_Column) == 'r_price') {
                        $rprice[] = $product_details->$v_column;
    					$saving = $saving + ($product_details->$v_column * $cart->qty);
                    }
                    // $less = $rprice * $qty;
                    // $price = array($less);
                    if(empty($whishlist)) {
                        $wflag = 'No';
                    } else {
                        $wflag = 'Yes';
                    }
                    $product_data['whishlist'] = $wflag;
                }
    		    $tax_total = $tax_total +  $tax_amount ;
    			$cart_qty_total =  $cart_qty_total + $cart->qty;
                $cart_data[] = array(
                        'cart_id'       => $cart->cart_id,
                        'product_data'  => $product_data,
                        'amount'        => $cart->amount,
                        'qty'           => $cart->qty,
                        'tax_amount'    => $tax_amount,
                        'delivery'      => $cart->delivery
                        // 'ptotal'        => $cart->amount * $cart->qty,
                );

                
                $qty[] = $cart->qty;
                //$merge = array_combine($rprice,$qty);

                

            }
    		/*
    		echo '<pre>';print_r($merge);exit;

            foreach ($merge as $keys => $val) {
                $saving[] = round($keys * $val);
            }*/
            
            $bags = DB::table('user_carry_bags')->select('vendor_carry_bags.Name','user_carry_bags.Qty','vendor_carry_bags.BAG_ID')->selectRaw('user_carry_bags.Qty * vendor_carry_bags.Price as Price')->leftJoin('vendor_carry_bags', 'user_carry_bags.Bag_ID', '=', 'vendor_carry_bags.BAG_ID')->where('user_carry_bags.V_ID', $v_id)->where('user_carry_bags.Store_ID', $store_id)->where('user_carry_bags.User_ID', $c_id)->where('user_carry_bags.Order_ID', $order_id)->get();
            $bprice = DB::table('user_carry_bags')->selectRaw('SUM(user_carry_bags.Qty * vendor_carry_bags.Price) as Price')->leftJoin('vendor_carry_bags', 'user_carry_bags.Bag_ID', '=', 'vendor_carry_bags.BAG_ID')->where('user_carry_bags.V_ID', $v_id)->where('user_carry_bags.Store_ID', $store_id)->where('user_carry_bags.User_ID', $c_id)->where('user_carry_bags.Order_ID', $order_id)->first();
            // $cart_data['bags'] = $bags;
    		
    		        
            if(empty($bprice->Price)) {
                $carry_bag_total = 0;
            } else {
                $carry_bag_total = $bprice->Price;
            }
            $total = (int)$sub_total + (int)$carry_bag_total;
            if($saving == 0){
               $less =0; 
            }else{
                $less = $saving - (int)$sub_total;
            }
    		
    		$offeredAmount = 0;
    		$grand_total = $sub_total + $carry_bag_total + $tax_total;
    		$offerUsed = PartnerOfferUsed::where('user_id',$c_id)->where('order_id',$order_id)->first();
            if( $offerUsed){
                

                $offers =  PartnerOffer::where('id',$offerUsed->partner_offer_id)->first();
    			if($offers){
                 if($offers->type == 'PRICE'){

                        $offerMsg = "Get Cash Back Upto $offers->value ";
                        $offeredAmount = $offers->value;
                    }else if($offers->type == 'PERCENTAGE'){
                        $offerMsg = "Get Upto $offers->value % Discount max upto $offers->max";
                        
                        $offeredAmount = ($grand_total  * $offers->value) / 100;
                        if( $offers->max != 0  && $offeredAmount >= $offers->max){
                            $offeredAmount = $offers->max;
                        }
                        
                    }

                   $grand_total = $grand_total - $offeredAmount;
    			}

            }
    		
            $store = DB::table('stores')->select('delivery')->where('store_id', $store_id)->where('v_id', $v_id)->first();
            // if ($store->delivery == 'Yes') {
            //     $product_data['delivery'] = $wflag;
            // }
            // $sub_total = (int)$sub_total + $bprice->Price;
            return response()->json(['status' => 'cart_details', 'message' => 'Your Cart Details', 'data' => $cart_data, 'product_image_link' => product_image_link(),'bags' => $bags, 'sub_total' => $sub_total, 'tax_total' => $tax_total,'grand_total' => $grand_total, 'order_id' => $order_id, 'carry_bag_total' => $carry_bag_total, 'total' => $total, 'cart_qty_total' => $cart_qty_total ,	'saving' => $less, 'delivered' => $store->delivery , 'offered_mount' => $offeredAmount ],200);
            // echo array_sum($saving);
        }
    }

    public function process_to_payment(Request $request)
    {
    	$v_id = $request->v_id;

        $v_id = $request->v_id;

        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->process_to_payment($request);
            return $response;

        } else if($v_id == 3) {
           
            $cartC = new  Vmart\CartController;
            $response = $cartC->process_to_payment($request);
            return $response;

        } else if($v_id == 26) {
           
            $cartC = new  Zwing\CartController;
            $response = $cartC->process_to_payment($request);
            return $response;

        }else if($v_id == 28) {
           
            $cartC = new  Dmart\CartController;
            $response = $cartC->process_to_payment($request);
            return $response;

        }else if($v_id == 30) {
           
            $cartC = new  Hero\CartController;
            $response = $cartC->process_to_payment($request);
            return $response;

        }else {

            $c_id = $request->c_id;
            $store_id = $request->store_id;
            $amount = $request->amount;

            $t_order_id = Order::where('user_id', $c_id)->where('status', 'success')->count();
            $t_order_id = $t_order_id + 1;
            $order_id = order_id_generate($store_id, $c_id);

            $order = new Order;

            $order->order_id = $order_id;
            $order->o_id = $t_order_id;
            $order->v_id = $v_id;
            $order->store_id = $store_id;
            $order->user_id = $c_id;
            $order->amount = $amount;
            $order->status = 'process';
            $order->date = date('Y-m-d');
            $order->time = date('h:i:s');
            $order->month = date('m');
            $order->year = date('Y');

            $order->save();

            return response()->json(['status' => 'proceed_to_payment', 'message' => 'Proceed to Payment', 'data' => $order ],200);
        }
    }

    public function payment_details(Request $request)
    {

        $v_id = $request->v_id;

        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->payment_details($request);
            return $response;

        } else if($v_id == 3) {
           
            $cartC = new  Vmart\CartController;
            $response = $cartC->payment_details($request);
            return $response;

        } else if($v_id == 26) {
           
            $cartC = new  Zwing\CartController;
            $response = $cartC->payment_details($request);
            return $response;

        }else if($v_id == 28) {
           
            $cartC = new  Dmart\CartController;
            $response = $cartC->payment_details($request);
            return $response;

        }else if($v_id == 30) {
           
            $cartC = new  Hero\CartController;
            $response = $cartC->payment_details($request);
            return $response;

        }else {

        	$store_id = $request->store_id;
        	$v_id = $request->v_id;
        	$t_order_id = $request->t_order_id;
        	$order_id = $request->order_id;
        	$user_id = $request->c_id;
        	$pay_id = $request->pay_id;
        	$amount = $request->amount;
        	$method = $request->method;
        	$invoice_id = $request->invoice_id;
        	$bank = $request->bank;
        	$wallet = $request->wallet;
        	$vpa = $request->vpa;
        	$error_description = $request->error_description;
        	$status = $request->status;
    		
    		$api_key = env('RAZORPAY_API_KEY');
            $api_secret = env('RAZORPAY_API_SECERET');

            $api = new Api($api_key, $api_secret);
            $razorAmount = $amount * 100;
            $razorpay_payment  = $api->payment->fetch($pay_id)->capture(array('amount'=>$razorAmount)); // Captures a payment
           
            if($razorpay_payment){

                if($razorpay_payment->status == 'captured'){

    				$payment = new Payment;

    				$payment->store_id = $store_id;
    				$payment->v_id = $v_id;
    				$payment->t_order_id = $t_order_id;
    				$payment->order_id = $order_id;
    				$payment->user_id = $user_id;
    				$payment->pay_id = $pay_id;
    				$payment->amount = $amount;
    				$payment->method = $razorpay_payment->method;
                    $payment->invoice_id = $razorpay_payment->invoice_id;;
                    $payment->bank = $razorpay_payment->bank;
                    $payment->wallet = $razorpay_payment->wallet;
                    $payment->vpa = $razorpay_payment->vpa;
    				$payment->error_description = $error_description;
    				$payment->status = $status;
    				$payment->date = date('Y-m-d');
    				$payment->time = date('h:i:s');
    				$payment->month = date('m');
    				$payment->year = date('Y');

    				$payment->save();
    				
    				//Order::where('order_id', $order_id)->update(['status' => $status]);
    				$ord = Order::where('order_id', $order_id)->first();
    				if($request->has('address_id')){
    				   $ord->address_id = $request->address_id;
    				}

    				$ord->status = $status;

    				$ord->save();

    				$cartss = Cart::where('store_id', $store_id)->where('v_id', $v_id)->where('order_id', $ord->o_id)->where('user_id', $user_id)->update(['status' => $status]);


    				return response()->json(['status' => 'payment_save', 'message' => 'Save Payment', 'data' => $payment ],200);
    		
    			}
    		
    		}

        }
    }

    public function order_qr_code(Request $request)
    {
        $order_id = $request->order_id;
        $qrCode = new QrCode($order_id);
        header('Content-Type: image/png');
        echo $qrCode->writeString();
    }

    public function order_pre_verify_guide(Request $request){
        $v_id = $request->v_id;

        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->order_pre_verify_guide($request);
            return $response;

        }else if($v_id == 26){
           
            $cartC = new  Zwing\CartController;
            $response = $cartC->order_pre_verify_guide($request);
            return $response;

        }else if($v_id == 28){
           
            $cartC = new  Dmart\CartController;
            $response = $cartC->order_pre_verify_guide($request);
            return $response;

        }else if($v_id == 30){
           
            $cartC = new  Hero\CartController;
            $response = $cartC->order_pre_verify_guide($request);
            return $response;

        }

    }

    
    public function order_details(Request $request)
    {
        $v_id = $request->v_id;

        if($v_id == 16) {
           
            $cartC = new  Spar\CartController;
            $response = $cartC->order_details($request);
            return $response;

        } else if($v_id == 3) {
           
            $cartC = new  Vmart\CartController;
            $response = $cartC->order_details($request);
            return $response;

        }else if($v_id == 26) {
           
            $cartC = new  Zwing\CartController;
            $response = $cartC->order_details($request);
            return $response;

        }else if($v_id == 28) {
           
            $cartC = new  Dmart\CartController;
            $response = $cartC->order_details($request);
            return $response;

        }else if($v_id == 30) {
           
            $cartC = new  Hero\CartController;
            $response = $cartC->order_details($request);
            return $response;

        } else {

            $v_id = $request->v_id;
            $c_id = $request->c_id;
            $store_id = $request->store_id; 
            $order_id = $request->order_id; 

            $o_id = Order::where('order_id', $order_id)->where('v_id', $v_id)->where('store_id', $store_id)->where('user_id', $c_id)->first();
            $order_num_id = Order::where('order_id', $order_id)->first();

            $cart_data = array();
            $product_data = [];
            $tax_total = 0;
            
            $carts = Cart::where('user_id', $c_id)->where('v_id', $v_id)->where('store_id', $store_id)->where('order_id', $o_id->o_id)->get();
            $sub_total = Cart::where('user_id', $c_id)->where('v_id', $v_id)->where('store_id', $store_id)->where('order_id', $o_id->o_id)->sum('amount');

            foreach ($carts as $key => $cart) {
                $api_link_column = DB::table('api_link')->select('API_Column','V_API_Column')->where('Table', 'zwv_inventory'.$v_id.$store_id)->where('cart_view', 1)->get();
                foreach ($api_link_column as $key => $value) {
                    $api_column_id = $value->API_Column;
                    $api_columns = DB::table('api_columns')->select('api_id','Name')->where('api_id', $api_column_id)->first();
                    $v_column = get_vendor_column_name($value->V_API_Column,$v_id,$store_id);
                    $product_details = DB::table('zwv_inventory'.$v_id.$store_id)->select($v_column,'tax_hsn_id','s_price as mrp')->where('barcode', $cart->barcode)->first();
                    $tax = DB::table('zwing_tax'.$v_id)->where('vtax_id', $product_details->tax_hsn_id)->first();
                    $tax_amount = $product_details->mrp * $cart->qty * $tax->igst_rate / 100;
                    $product_data[get_api_column_name($value->API_Column)] = $product_details->$v_column;
                    if(get_api_column_name($value->API_Column) == 'images'){
                        $product_data['product_image_link'] = product_image_link().$product_details->$v_column;
                    }

                }

                $cart_data[] = array(
                        'cart_id'       => $cart->cart_id,
                        'product_data'  => $product_data,
                        'amount'        => $cart->amount ,
                        'qty'           => $cart->qty,
                        'tax_amount'    => $tax_amount,
                        'delivery'      => $cart->delivery
                );
                $tax_total = $tax_total +  $tax_amount ;
            }

            $bags = DB::table('user_carry_bags')->select('vendor_carry_bags.Name','user_carry_bags.Qty','vendor_carry_bags.BAG_ID')->selectRaw('user_carry_bags.Qty * vendor_carry_bags.Price as Price')->leftJoin('vendor_carry_bags', 'user_carry_bags.Bag_ID', '=', 'vendor_carry_bags.BAG_ID')->where('user_carry_bags.V_ID', $v_id)->where('user_carry_bags.Store_ID', $store_id)->where('user_carry_bags.User_ID', $c_id)->where('user_carry_bags.Order_ID', $order_num_id['o_id'])->get();
            $bprice = DB::table('user_carry_bags')->selectRaw('SUM(user_carry_bags.Qty * vendor_carry_bags.Price) as Price')->leftJoin('vendor_carry_bags', 'user_carry_bags.Bag_ID', '=', 'vendor_carry_bags.BAG_ID')->where('user_carry_bags.V_ID', $v_id)->where('user_carry_bags.Store_ID', $store_id)->where('user_carry_bags.User_ID', $c_id)->where('user_carry_bags.Order_ID', $order_num_id['o_id'])->first();
            // $cart_data['bags'] = $bags;
            
            if(empty($bprice->Price)) {
                $carry_bag_total = 0;
            } else {
                $carry_bag_total = $bprice->Price;
            }
            $store = DB::table('stores')->select('delivery')->where('store_id', $store_id)->where('v_id', $v_id)->first();
            //$total = (int)$sub_total + (int)$carry_bag_total;
            //$less = array_sum($saving) - (int)$sub_total;
    		$address = (object)array();
    		if($o_id->address_id > 0){
    			$address = Address::where('c_id', $c_id)->where('deleted_status', 0)->where('id',$o_id->address_id)->first();
    		}

            return response()->json(['status' => 'order_details', 'message' => 'Order Details Details', 'data' => $cart_data, 'sub_total' => $sub_total, 'tax_total' => $tax_total, 'grand_total' => $sub_total + $carry_bag_total + $tax_total, 'date' => $o_id->date, 'time' => $o_id->time, 'bags' => $bags, 'carry_bag_total' => $carry_bag_total, 'delivered' => $store->delivery , 'address'=> $address  ],200);

        }
    }

    public function order_receipt($c_id,$v_id , $store_id, $order_id){
        //dd($request);
        //echo $v_id ;exit;
        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->order_receipt($c_id, $v_id , $store_id, $order_id);
           // return $response;
            echo $response;

        }else if($v_id == 26){
           
            $cartC = new  Zwing\CartController;
            $response = $cartC->order_receipt($c_id, $v_id , $store_id, $order_id);
           // return $response;
            echo $response;

        }else if($v_id == 28){
           
            $cartC = new  Dmart\CartController;
            $response = $cartC->order_receipt($c_id, $v_id , $store_id, $order_id);
           // return $response;
            echo $response;

        }else if($v_id == 30){
           
            $cartC = new  Hero\CartController;
            $response = $cartC->order_receipt($c_id, $v_id , $store_id, $order_id);
           // return $response;
            echo $response;

        }
        
    }


    public function get_carry_bags(Request $request)
    {
        $v_id = $request->v_id;
        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->get_carry_bags($request);
            return $response;

        }else if($v_id == 3){
           
            $cartC = new  Vmart\CartController;
            $response = $cartC->get_carry_bags($request);
            return $response;

        }else if($v_id == 26){
           
            $cartC = new  Zwing\CartController;
            $response = $cartC->get_carry_bags($request);
            return $response;

        }else if($v_id == 28){
           
            $cartC = new  Dmart\CartController;
            $response = $cartC->get_carry_bags($request);
            return $response;

        }else if($v_id == 30){
           
            $cartC = new  Hero\CartController;
            $response = $cartC->get_carry_bags($request);
            return $response;

        }else{

            $store_id = $request->store_id; 
            $order_id = Order::where('user_id', Auth::user()->c_id)->where('status', 'success')->count();
            $order_id = $order_id + 1;

            $carry_bags = DB::table('vendor_carry_bags')->select('BAG_ID','Name','Price')->where('V_ID', $v_id)->where('Store_ID', $store_id)->get();
            $data = array();
            foreach ($carry_bags as $key => $value) {
                $bags = DB::table('user_carry_bags')->select('Qty','Bag_ID')->where('V_ID', $v_id)->where('Store_ID', $store_id)->where('User_ID', Auth::user()->c_id)->where('Order_ID', $order_id)->where('Bag_ID', $value->BAG_ID)->first();
                if(empty($bags)) {
                    $data[] = array(
                            'BAG_ID' => $value->BAG_ID,
                            'Name' => $value->Name,
                            'Price' => $value->Price,
                            'Qty' => 0,
                    );
                } else {
                    if($value->BAG_ID == $bags->Bag_ID) {
                        $data[] = array(
                                'BAG_ID' => $value->BAG_ID,
                                'Name' => $value->Name,
                                'Price' => $value->Price,
                                'Qty' => $bags->Qty,
                        );
                    } else {
                        $data[] = array(
                                'BAG_ID' => $value->BAG_ID,
                                'Name' => $value->Name,
                                'Price' => $value->Price,
                                'Qty' => 0,
                        );
                    }
                }
                
                
            }
            return response()->json(['status' => 'get_carry_bags_by_store', 'data' => $data ],200);
        }
    }

    public function save_carry_bags(Request $request)
    {
        $v_id = $request->v_id;
        if($v_id == 16){
           
            $cartC = new  Spar\CartController;
            $response = $cartC->save_carry_bags($request);
            return $response;

        }else if($v_id == 3){
           
            $cartC = new  Vmart\CartController;
            $response = $cartC->save_carry_bags($request);
            return $response;

        }else if($v_id == 26){
           
            $cartC = new  Zwing\CartController;
            $response = $cartC->save_carry_bags($request);
            return $response;

        }else if($v_id == 28){
           
            $cartC = new  Dmart\CartController;
            $response = $cartC->save_carry_bags($request);
            return $response;

        }else if($v_id == 30){
           
            $cartC = new  Hero\CartController;
            $response = $cartC->save_carry_bags($request);
            return $response;

        }else{

            $v_id = $request->v_id;
            $store_id = $request->store_id; 
            $c_id = $request->c_id; 
            $order_id = $request->order_id; 
            $bags = $request->bags; 
    	    $bags = json_decode($bags, true);
            foreach ($bags as $key => $value) {
                $exists = DB::table('user_carry_bags')->where('V_ID', $v_id)->where('Store_ID', $store_id)->where('User_ID', $c_id)->where('Order_ID', $order_id)->where('Bag_ID', $value[0])->first();
                if(empty($exists)) {
                    $add = DB::table('user_carry_bags')->insert(
                        ['V_ID' => $v_id, 'Store_ID' => $store_id, 'User_ID' => $c_id, 'Order_ID' => $order_id, 'Bag_ID' => $value[0], 'Qty' => $value[1]]
                    );
                    $status = '1';
                } else {
                    if(empty($value[1])) {
                        $update = DB::table('user_carry_bags')->where('V_ID', $v_id)->where('Store_ID', $store_id)->where('User_ID', $c_id)->where('Order_ID', $order_id)->where('Bag_ID', $value[0])->update(['Qty' => $value[1]]);
                        $delete = DB::table('user_carry_bags')->where('V_ID', $v_id)->where('Store_ID', $store_id)->where('User_ID', $c_id)->where('Order_ID', $order_id)->where('Bag_ID', $value[0])->delete();
                    } else {
                        $delete = DB::table('user_carry_bags')->where('V_ID', $v_id)->where('Store_ID', $store_id)->where('User_ID', $c_id)->where('Order_ID', $order_id)->where('Bag_ID', $value[0])->update(['Qty' => $value[1]]);  
                    }
                    $status = '2';
                }
            }
            if($status == 1) {
                return response()->json(['status' => 'add_carry_bags', 'message' => 'Carry Bags Added'],200);
            } else {
                return response()->json(['status' => 'add_carry_bags', 'message' => 'Carry Bags Updated'],200);
            }
            //print_r($
            // $carry_bags = DB::table('vendor_carry_bags')->select('BAG_ID','Name','Price')->where('V_ID', $v_id)->where('Store_ID', $store_id)->get();
            // return response()->json(['status' => 'get_carry_bags_by_store', 'data' => print_r(expression)$bags ],200);
        }
    }

    public function deliveryStatus(Request $request)
    {
        
        $c_id = $request->c_id;
        // $v_id = $request->v_id;
        // $store_id = $request->store_id;
        $cart_id = $request->cart_id;
        $status = $request->status;

        $cart = Cart::find($cart_id)->update([ 'delivery' => $status ]);

        return response()->json(['status' => 'delivery_status_update'],200);
    }

    public function get_print_receipt(Request $request)
    {
        
        if ($request->v_id == 16) {
            $cartC = new  Spar\CartController;
            $response = $cartC->get_print_receipt($request);
            return $response;
        } else if ($request->v_id == 3) { 
            $cartC = new  Vmart\CartController;
            $response = $cartC->get_print_receipt($request);
            return $response;
        } else if ($request->v_id == 26) { 
            $cartC = new  Zwing\CartController;
            $response = $cartC->get_print_receipt($request);
            return $response;
        } else if ($request->v_id == 28) { 
            $cartC = new  Dmart\CartController;
            $response = $cartC->get_print_receipt($request);
            return $response;
        } else if ($request->v_id == 30) { 
            $cartC = new  Hero\CartController;
            $response = $cartC->get_print_receipt($request);
            return $response;
        }
    }

}