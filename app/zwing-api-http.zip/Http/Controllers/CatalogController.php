<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\VendorSettingController;
use Illuminate\Http\Request;
use DB;

use App\Cart;

class CatalogController extends Controller
{

    public function __construct()
	{
		//$this->middleware('auth');
	}

	public function getCatalog(Request $request){
		$v_id = $request->v_id;
		 if($v_id == 28) {

            $cataC = new  Dmart\CatalogController;
            $response = $cataC->getCatalog($request);
            return $response;

        } else if($v_id == 30) {

            $cataC = new  Hero\CatalogController;
            $response = $cataC->getCatalog($request);
            return $response;

        }

	}

    public function saveCatalog(Request $request){
        
        $v_id = $request->v_id;
        if($v_id == 28) {

            $cataC = new  Dmart\CatalogController;
            $response = $cataC->saveCatalog($request);
            return $response;

        } else if($v_id == 30) {

            $cataC = new  Hero\CatalogController;
            $response = $cataC->saveCatalog($request);
            return $response;

        }

    }

}