<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Offer;
use App\Wishlist;
use App\Scan;
use Auth;

class ProductController extends Controller
{

	public function __construct()
	{
		$this->middleware('auth');
	}

    public function product_details(Request $request)
    {
        $v_id = $request->v_id;

        if($v_id == 16){

            $productC = new  Spar\ProductController;

            $response = $productC->product_details($request);

            return $response;

        } elseif($v_id == 3) {

            $productC = new  Vmart\ProductController;

            $response = $productC->product_details($request);

            return $response;

        } elseif($v_id == 26) {

            $productC = new  Zwing\ProductController;

            $response = $productC->product_details($request);

            return $response;

        }elseif($v_id == 28) {

            $productC = new  Dmart\ProductController;

            $response = $productC->product_details($request);

            return $response;

        }elseif($v_id == 30) {

            $productC = new  Hero\ProductController;

            $response = $productC->product_details($request);

            return $response;

        }else {


            $store_id = $request->store_id;
            $barcode = $request->barcode;
            $c_id = $request->c_id;
            $scanFlag = $request->scan;
            $product_data = array();
            $store_name = DB::table('stores')->select('name')->where('store_id', $store_id)->first()->name;

            $api_link_column = DB::table('api_link')->select('API_Column','V_API_Column')->where('Table', 'zwv_inventory'.$v_id.$store_id)->get();

            $product_count = DB::table('zwv_inventory'.$v_id.$store_id)->where('barcode', $barcode)->first();
            
            if(empty($product_count)) {
                return response()->json(['status' => 'product_not_found', 'message' => 'Product Not Found' ], 404);
            }
            $type = 0;
            $offer_arr = array();
            foreach ($api_link_column as $key => $value) {

                $api_column_id = $value->API_Column;
                $api_columns = DB::table('api_columns')->select('api_id','Name')->where('api_id', $api_column_id)->first();
                $v_column = get_vendor_column_name($value->V_API_Column,$v_id,$store_id);
                $product_details = DB::table('zwv_inventory'.$v_id.$store_id)->select($v_column)->where('barcode', $barcode)->first();
                $product_data[get_api_column_name($value->API_Column)] = $product_details->$v_column;
                
                foreach ($product_data as $key => $val) {
                    if($key == 'r_price') {
                        $type = $val;
                    } 
                    if($key == 'offer') {
                        if(!empty($val)) {
                            $offer_data = Offer::select('name','type','value','offer_default')->whereRaw("find_in_set('".$val."',terms)")->first()->toArray();
                            $price = round($type - $type * $offer_data['value'] / 100);
                            $offer_array[] = array_merge(array('price' => $price),$offer_data);
                            foreach ($offer_array as $key => $value) {
                                if(!empty($value['price'])) {
                                    $offer_arr[] = $value;
                                }  
                            }
                            $product_data['offer_data'] = array_unique($offer_arr, SORT_REGULAR);
                        } else {
                            $product_data['offer_data'] = [];
                        }
                    }

                    if($key == 'p_id') {
                        if($v_id == 15) {
                            $ti = DB::table('zwing_add'.$v_id.$store_id)->select('title','type','description')->where('product_id', $val)->where('type', 'ti')->get();
                            $advantage = DB::table('zwing_add'.$v_id.$store_id)->select('title','type','description')->where('product_id', $val)->where('type', 'advantage')->get();
                            $ict = DB::table('zwing_add'.$v_id.$store_id)->select('title','type','description')->where('product_id', $val)->where('type', 'ict')->get();
                            $char = DB::table('zwing_add'.$v_id.$store_id)->select('title','type','description')->where('product_id', $val)->where('type', 'char')->get();
                            $data_add = array();
                            $data_add = array(
                                'ti' => $ti,
                                'advantage' => $advantage,
                                'ict' => $ict,
                                'char' => $char
                            );
                            $product_data['additionals'] = $data_add;
                        }
                    }

                }
                // if(get_api_column_name($value->API_Column) == 'offer') {
                //     $offer_data = Offer::select('name','type','value','offer_default')->whereRaw("find_in_set('".$product_details->$v_column."',terms)")->first();
                //     $product_data['offer_data'][] = $offer_data;
                //     $product_data['s_price'] = $type - $type * $offer_data->value / 100;
                // }
            }
            
            $rating = new ProductRatingController;
            $rating = $rating->get_rating($request);
            if($rating['status'] != 'fail'){
                if($rating['data']['count'] >= 1){
                    $product_data['rating'] = $rating['data']['star'];
                    $product_data['rating_no'] =  $rating['data']['count'];
                }
            }

            $review = new ProductReviewController;
            $review = $review->get_review($request);

            if($review['status'] != 'fail'){
                $product_data['review'] = $review['data'];
            }
            
            $whishlist = Wishlist::where('v_id', $v_id)->where('store_id', $store_id)->where('barcode', $barcode)->where('user_id', Auth::user()->c_id)->count();
            if(empty($whishlist)) {
                $product_data['whishlist'] = 'No';
            } else {
                $product_data['whishlist'] = 'Yes';
            }
            
            
            //Adding Entry when Product scan is done
            if(!empty($product_data)){
                if($scanFlag == 'TRUE'){
                    $scan = new Scan;
                    $scan->store_id = $store_id;
                    $scan->v_id = $v_id;
                    $scan->user_id = $c_id;
                    $scan->product_id = $product_data['p_id'];
                    $scan->barcode = $barcode;
                    $scan->date = date('Y-m-d');
                    $scan->time = date('h:i:s');
                    $scan->month = date('m');
                    $scan->year = date('Y');

                    $scan->save();
                }
            }



            return response()->json(['status' => 'get_product_details', 'message' => 'Get Product Details', 'data' => $product_data, 'product_image_link' => product_image_link().$product_data['images'], 'store_name' => $store_name ],200);

        }
 
    }
	
	public function product_search(Request $request){
        $v_id = $request->v_id;

        if($v_id == 16){

            $productC = new  Spar\ProductController;
            $response = $productC->product_search($request);
            return $response;


        }else if($v_id == 26){

            $productC = new  Zwing\ProductController;
            $response = $productC->product_search($request);
            return $response;


        }else if($v_id == 28){

            $productC = new  Dmart\ProductController;
            $response = $productC->product_search($request);
            return $response;


        }else if($v_id == 30){

            $productC = new  Hero\ProductController;
            $response = $productC->product_search($request);
            return $response;


        }else{

            $store_id = $request->store_id;
            $search_term = $request->search_term;

            $product = DB::table('zwv_inventory'.$v_id.$store_id)->select('product_id','barcode','r_price','s_price','product_name','image')->where('product_name', 'LIKE','%'.$search_term.'%')->orderBy('product_name', 'asc')->get();

            return response()->json(['status' => 'get_product_search', 'message' => 'Get Product Search', 'data' => $product ,'product_image_link' => product_image_link() ],200);

        }
        


    }
}
