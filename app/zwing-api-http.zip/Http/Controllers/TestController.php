<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\VendorSetting;

class TestController extends Controller
{

	public function phpinfo(Request $request){
		phpinfo();
	}

	public function verify_order_for_test(Request $request){

	
		DB::table('orders')->where('order_id', $request->order_id)->update(['verify_status' => $request->verify_status,  'verify_status_guard' => $request->verify_status_guard ]);
		return response()->json(['status' => 'success', 'message' => 'Data updated successfully'],200);
	}

	public function get_vendor_settings(Request $request){
		$v_id = $request->v_id;
		$name = $request->setting_name;

		$settings = VendorSetting::select('name','settings')->where('v_id',$v_id)->where('name',$name)->first();
		$settings = json_decode($settings->settings);

		return response()->json(['status' => 'success' , 'data' => $settings],200);


	}

	public function update_vendor_settings(Request $request){
		$v_id = $request->v_id;
		$name = $request->setting_name;
		$settings_data = json_decode($request->settings);

		//dd(json_decode($request->settings));

		$settings = VendorSetting::where('v_id',$v_id)->where('name',$name)->first();
		$settings->settings = json_encode($settings_data);
		$settings->save();


		return response()->json(['status' => 'success' , 'data' => "Data updated successfully"],200);

	}

}