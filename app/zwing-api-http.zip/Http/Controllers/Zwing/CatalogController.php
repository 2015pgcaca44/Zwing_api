<?php

namespace App\Http\Controllers\Zwing;

use App\Http\Controllers\Controller;
use App\Http\Controllers\VendorSettingController;
use Illuminate\Http\Request;
use DB;

use App\Cart;

class CatalogController extends Controller
{

    public function __construct()
	{
		//$this->middleware('auth');
	}

	public function getCatalog(Request $request){

		$v_id = $request->v_id;
        $store_id = $request->store_id; 
        $c_id = $request->c_id;

        $stores =  DB::table('stores')->where('v_id', $v_id)->where('store_id', $store_id)->first();
        $store_db_name = $stores->store_db_name;

		$item_master = DB::table($store_db_name.'.item_master as im')
						->join($store_db_name.'.price_master as pm', 'pm.ITEM' ,'im.EAN')
						->where('pm.IS_CATALOG','1')->get();

		$carts = Cart::where('user_id', $c_id)->where('v_id', $v_id)->where('store_id', $store_id)->where('status','process')->orderBy('updated_at','desc')->get();

		$total = $carts->sum('total');
		$cart_qty_total = $carts->sum('qty');
		$cartItems = $carts->pluck('qty','item_id')->all();;

		$items = $item_master->pluck('');
		$data = [];
		foreach($item_master as $product){
			
			$qty = 0;
			$cart_id = '';
			if(isset($cartItems[$product->ITEM])){
				$qty = $cartItems[$product->ITEM];
				$cart = $carts->where('item_id', $product->ITEM)->first();
				$cart_id = $cart->cart_id;
			}
			$data[$product->CATEGORY][] = [ 'item_name' => $product->ITEM_DESC ,
						'images' => $product->IMAGE,
						'unit_mrp' => $product->MRP1,
						'category' => $product->CATEGORY,
						'qty' => (string)$qty,
						'barcode' => $product->ITEM,
						'cart_id' => $cart_id
					 ];
		}

		$response = [];
		foreach($data as $key =>  $d){
			$response[] = [ 'title' => $key , 'data' => $d ]; 
		}

		return response()->json(['status' => 'success' , 'catalog_data' => $response , 'product_image_link' => product_image_link().$v_id.'/', 'total' => format_number($total) , 'cart_qty_total' => (string)$cart_qty_total ],200);

	}

}