<?php

namespace App\Http\Middleware;

use App\Http\Controllers\VendorSettingController;
use App\SettlementSession;
use DB;
use App\Vendor;
use Closure;

class VendorMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {   

        /*$vu_id =  $request->vu_id;
        $trans_from = 'ANDROID_VENDOR';
        if($request->has('trans_from')){
            $trans_from = $request->trans_from;
        }

        $vendorUser = Vendor::select('vendor_id','store_id')->where('vu_id' , $vu_id)->first();
        $v_id = $vendorUser->vendor_id;
        $store_id = $vendorUser->store_id;
        
        $vendorS = new VendorSettingController;
        $paymentTypeSettings = $vendorS->getPaymentTypeSetting(['v_id' => $v_id, 'trans_from' => $trans_from]);
        $cash_status = 0;
        foreach($paymentTypeSettings as $type){
            if($type->name == 'cash' && $type->status == 1){
                $cash_status = 1;
            }
        }

        if($cash_status){

            $current_date = date('Y-m-d' , strtotime('-1 days'));
            $settlementSession = SettlementSession::where(['v_id' => $v_id ,'store_id' => $store_id , 'vu_id' => $vu_id , 'type' => 'CASH' , 'trans_from' => $trans_from , 'settlement_date' => $current_date ])->first();
            if($settlementSession){
                if(empty($settlementSession->closing_balance) ||  $settlementSession->closing_balance = '' || $settlementSession->closing_balance == null){

                    return response()->json([ 'status' => 'fail', 'message' => 'Your Previous Settelment is pending'], 200);
                }
            }
        }*/
        
        return $next($request);
    }
}
